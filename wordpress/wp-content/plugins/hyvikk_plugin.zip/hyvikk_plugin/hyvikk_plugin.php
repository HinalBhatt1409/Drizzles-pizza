<?php

/**
 


*Plugin Name:Hyvikk plugin
*Plugin URI: localhost/demo-plugin.com/plugin
*Description: Hyvikk_plugin used for add extra subscripton fees and without login it can not access any page  of website.
*Version: 1.0.0

*Author: Hyvikk
*Author URI: https://hyvikk.com

*/

if(!defined('ABSPATH'))
{
 
  die("");
}

/**
 * Removes some menus by page.
 */
if ( ! function_exists( 'deregister_post_type' ) ) {
    function wpdocs_remove_menus(){
    //   remove_menu_page( 'index.php' );                  //Dashboard
    //   remove_menu_page( 'jetpack' );                    //Jetpack* 
      remove_menu_page( 'edit.php' );                   //Posts
      remove_menu_page( 'upload.php' );                 //Media
      remove_menu_page( 'edit.php?post_type=page' );    //Pages
      remove_menu_page( 'edit-comments.php' );          //Comments
      remove_menu_page( 'themes.php' );                 //Appearance
      remove_menu_page( 'plugins.php' );                //Plugins
    //   remove_menu_page( 'users.php' );                  //Users
      remove_menu_page( 'tools.php' );                  //Tools
      remove_menu_page( 'options-general.php' );        //Settings
    }
   }
   add_action( 'admin_menu', 'wpdocs_remove_menus' );

   function my_remove_admin_menus($features) {
    //    $analytics = array_search('analytics', $features);
    //    unset($features[$analytics]);
       
       $marketing = array_search('marketing', $features);
       unset($features[$marketing]);
       
       return $features;	 	 
    }
    add_filter( 'woocommerce_admin_features', 'my_remove_admin_menus' );

    add_action( 'template_redirect', 'custom_login_redirect' );

    function custom_login_redirect( $redirect ) {
        $is_user_logged_in = is_user_logged_in();
        // Check if user is not logged in
        if ( $is_user_logged_in && is_page( 'wp-login.php' ) ) {
            // Redirect admins to the dashboard
            if ( current_user_can( 'manage_options' ) ) {
                wp_redirect( admin_url() );
            } else if ( !empty( wp_get_current_user()->roles ) && is_array( wp_get_current_user()->roles ) && in_array( 'customer', wp_get_current_user()->roles ) ) {
                // Redirect the user to the shop page
                wp_redirect( home_url() );
                
            }
          
        } elseif ( ! $is_user_logged_in && is_shop() ) {
            // Get the login page URL
            $login_page_url = wp_login_url( get_permalink() );
            // Redirect to the login page URL
            wp_redirect( $login_page_url );
            exit;
        }
    }
    

function redirect_customer_to_shop_page() {
    // Check if the user is a customer
    if ( !empty( wp_get_current_user()->roles ) && is_array( wp_get_current_user()->roles ) && in_array( 'customer', wp_get_current_user()->roles ) ) {
        // Redirect the user to the shop page
        wp_redirect( get_permalink( get_option( 'woocommerce_shop_page_id' ) ) );
        exit;
    }
}
// add_action( 'wp_login', 'redirect_customer_to_shop_page' );
function redirect_users_after_login() {
    // Check if the user is a customer
    if ( !empty( wp_get_current_user()->roles ) && is_array( wp_get_current_user()->roles ) && in_array( 'customer', wp_get_current_user()->roles ) ) {
        // Redirect the customer to the shop page
        wp_redirect( get_permalink( get_option( 'woocommerce_shop_page_id' ) ) );
        exit;
    }

    // Check if the user is an administrator
   elseif ( current_user_can( 'manage_options' ) ) {
        // Redirect the user to the dashboard
        wp_redirect( admin_url() );
        exit;
    }
}
// add_action( 'wp_login', 'redirect_users_after_login' );

// add_action( 'woocommerce_cart_calculate_fees', 'add_custom_fee', 10, 1 );
function add_custom_fee1( $cart ) {
    
   if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;
   $fee_amount = 20; // Change this to the amount you want to charge.
   $fee_name = 'Custom Fee'; // Change this to the name of your fee.
   $cart->add_fee( $fee_name, $fee_amount, true, '' );
}
// add_action( 'woocommerce_cart_calculate_fees', 'add_custom_fee', 10, 1 );
function add_custom_fee2( $cart ) {
   if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;
   
   $fee_name = 'Subscription Charges'; // Change this to the name of your fee.
   $fee_amount = 5000; // Change this to the amount you want to charge.
   
   $last_order_date = get_last_order_date(); // Get the date of the last order.
   $days_since_last_order = ( time() - strtotime( $last_order_date ) ) / ( 60 * 60 * 24 ); // Calculate days since last order.
   
   if ( $days_since_last_order <= 30 ) {
      $cart->remove_coupon( $fee_name ); // Remove the fee if the last order was placed within the last 30 days.
   } else {
      $cart->add_fee( $fee_name, $fee_amount, true, '' ); // Add the fee if the last order was placed more than 30 days ago.
   }
}

function get_last_order_date1() {
   global $wpdb;
   $last_order_date = $wpdb->get_var( "
      SELECT post_date
      FROM {$wpdb->posts}
      WHERE post_type = 'shop_order'
      AND post_status IN ( 'wc-completed', 'wc-processing' )
      ORDER BY post_date DESC
      LIMIT 1
   " );
   return $last_order_date;
}

add_action( 'woocommerce_cart_calculate_fees', 'add_custom_fee', 10, 1 );
function add_custom_fee( $cart ) {
   if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;
   
   $fee_name = 'Subscription Charges'; // Change this to the name of your fee.
   $fee_amount = 5000; // Change this to the amount you want to charge.
   
   $last_order_date = get_last_order_date(); // Get the date of the last order.
   $minutes_since_last_order = ( time() - strtotime( $last_order_date ) ) / 60; // Calculate minutes since last order.
   
   if ( $minutes_since_last_order <= 5 ) {
      $cart->remove_coupon( $fee_name ); // Remove the fee if the last order was placed within the last 5 minutes.
   } else {
      $cart->add_fee( $fee_name, $fee_amount, true, '' ); // Add the fee if the last order was placed more than 5 minutes ago.
   }
}

function get_last_order_date() {
   global $wpdb;
   $last_order_date = $wpdb->get_var( "
      SELECT post_date
      FROM {$wpdb->posts}
      WHERE post_type = 'shop_order'
      AND post_status IN ( 'wc-completed', 'wc-processing' )
      ORDER BY post_date DESC
      LIMIT 1
   " );
   return $last_order_date;
}

add_filter( 'woocommerce_account_menu_items', 'remove_account_links' );
function remove_account_links( $menu_links ){

    // Remove the "Downloads" link
    unset( $menu_links['downloads'] );

    // Remove the "Account Details" link
    unset( $menu_links['edit-account'] );

    return $menu_links;
}





   ?>

